// INSTRUCTIONS STEP2 -->
// Créez les variables "integer", "float", "string", "bool", "null", "array".
// Affectez les valeurs suivantes aux variables dont le nom correspond au type de la valeur :
// true, [], "quarante-deux", 42, NULL et 42.42
var integer = 42;
var float = 42.42;
var string = "quarante-deux";
var bool = true;
var null = NULL;
var array = [];
